import org.junit.jupiter.api.Test;
import projectx.model.Backpack;

public class WeaponTest {


    //@Test
    //public void setup


    //@Test
    //public void ZombiesServiceGetWeaponTest() {


}

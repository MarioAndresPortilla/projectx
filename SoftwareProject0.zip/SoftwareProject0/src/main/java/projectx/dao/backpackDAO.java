package projectx.dao;
import projectx.model.Backpack;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import static projectx.driver.Driver.conn;

public class backpackDAO {



}